#!/bin/bash

docker run -p 80:80 nebula
