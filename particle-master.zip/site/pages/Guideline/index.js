import React from 'react';
import { Page } from 'controls';

export default () => (
  <Page name="Guideline">
    <div>some</div>
    <div>content</div>
  </Page>
);
