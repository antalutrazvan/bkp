import React from 'react';
import { Page } from 'controls';

export default () => (
  <Page name="What's New">
    <div>some</div>
    <div>content</div>
  </Page>
);
