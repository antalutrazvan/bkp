import React from 'react';
import { Page } from 'controls';

export default () => (
  <Page name="Motion">
    <div>some</div>
    <div>content</div>
  </Page>
);
