import React from 'react';
import { Page } from 'controls';

export default () => (
  <Page name="Get Started">
    <div>some</div>
    <div>content</div>
  </Page>
);
