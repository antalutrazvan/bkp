import React from 'react';
import { Page } from 'controls';

export default () => (
  <Page name="Load More Scroll">
    <div>load more</div>
    <div>scroll</div>
  </Page>
);
