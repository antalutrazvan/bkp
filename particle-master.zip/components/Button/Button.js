import React, { Component } from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';

class PlainButton extends Component {
  render() {
    const { theme, secondary, disabled, missing, onClick, children } = this.props;
    const primary = !secondary;
    const classes = classNames(theme.button, {
      [theme.primary]: primary,
      [theme.secondary]: secondary,
      [theme.disabled]: disabled,
      [theme.missing]: missing
    });

    return (
      <button disabled={disabled} className={classes} onClick={onClick}>
        {children}
      </button>
    );
  }
}

PlainButton.propTypes = {
  theme: PropTypes.object.isRequired,
  secondary: PropTypes.bool,
  disabled: PropTypes.bool,
  missing: PropTypes.bool,
  onClick: PropTypes.func,
  children: PropTypes.node,
  ComponentB: PropTypes.shape(PlainButton.propTypes),
  nestedButtonOptions: PropTypes.shape({
    t1: PropTypes.string,
    t2: PropTypes.string,
    t3: PropTypes.bool,
    t4: PropTypes.object,
    t5: PropTypes.object
  })
};

PlainButton.defaultProps = {
  theme: {},
  nestedButtonOptions: {
    t1: 'someValue',
    t2: 'someValue',
    t3: true,
    t4: {},
    t5: {}
  },
  ComponentB: PlainButton.defaultProps
};

export default PlainButton;
